import React, { useState, useCallback } from 'react';
import { AppStatus, Gender, OutfitOption, ImageState } from './types';
import { analyzeImage, generateProfessionalHeadshot } from './services/geminiService';
import ImageUploader from './components/ImageUploader';
import OutfitSelector from './components/OutfitSelector';
import ResultView from './components/ResultView';
import { Sparkles, Loader2, AlertTriangle, User } from 'lucide-react';

// Outfit presets for women
const FEMALE_OUTFITS: OutfitOption[] = [
  {
    id: 'opt1',
    description: "Dark blazer with light blouse",
    promptFragment: "Wear a fitted women's dark navy blazer with a clean white blouse. Ensure it looks like a natural women's business outfit, not a men's suit.",
  },
  {
    id: 'opt2',
    description: "Light blazer with neutral top",
    promptFragment: "Wear a modern women's light grey or beige blazer with a simple neutral top. Professional and modest.",
  },
  {
    id: 'opt3',
    description: "Elegant business dress",
    promptFragment: "Wear an elegant, modest professional business dress in a solid neutral color with sleeves. Appropriate for a corporate environment.",
  }
];

// Outfit preset for men (auto-applied)
const MALE_OUTFIT_PROMPT = "Wear a formal business outfit: A classic suit jacket (navy, black, or grey), a dress shirt, and an optional tie. Professional and suitable for a CV.";

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [imageState, setImageState] = useState<ImageState>({ original: null, final: null, mimeType: '' });
  const [gender, setGender] = useState<Gender>(Gender.UNKNOWN);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loadingMsg, setLoadingMsg] = useState<string>('');

  const handleImageSelected = useCallback(async (base64: string, mimeType: string) => {
    setImageState({ original: base64, final: null, mimeType });
    setStatus(AppStatus.ANALYZING);
    setLoadingMsg("Scanning facial features...");
    setErrorMsg(null);

    try {
      // Step 1: Analyze Image
      const analysis = await analyzeImage(base64, mimeType);

      if (!analysis.valid) {
        setStatus(AppStatus.ERROR);
        setErrorMsg(analysis.message || "Face detection failed. Please upload a clearer photo.");
        return;
      }

      setGender(analysis.gender);

      if (analysis.gender === Gender.MALE) {
        // Auto-process for Male
        startProcessing(base64, mimeType, Gender.MALE, MALE_OUTFIT_PROMPT);
      } else {
        // Show options for Female (or unknown/default to female options)
        setStatus(AppStatus.SELECTING);
      }

    } catch (err) {
      console.error(err);
      setStatus(AppStatus.ERROR);
      setErrorMsg("An unexpected error occurred during analysis.");
    }
  }, []);

  const handleOutfitSelect = (option: OutfitOption) => {
    if (imageState.original && imageState.mimeType) {
      startProcessing(imageState.original, imageState.mimeType, Gender.FEMALE, option.promptFragment);
    }
  };

  const startProcessing = async (base64: string, mimeType: string, gender: Gender, outfitPrompt: string) => {
    setStatus(AppStatus.PROCESSING);
    setLoadingMsg("Applying professional studio styling...");

    try {
      const resultBase64 = await generateProfessionalHeadshot(base64, mimeType, gender, outfitPrompt);
      
      if (resultBase64) {
        setImageState(prev => ({ ...prev, final: resultBase64 }));
        setStatus(AppStatus.COMPLETE);
      } else {
        throw new Error("Failed to generate image.");
      }
    } catch (err) {
      console.error(err);
      setStatus(AppStatus.ERROR);
      setErrorMsg("Failed to generate the professional photo. Please try again.");
    }
  };

  const handleReset = () => {
    setStatus(AppStatus.IDLE);
    setImageState({ original: null, final: null, mimeType: '' });
    setGender(Gender.UNKNOWN);
    setErrorMsg(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">ProHeadshot AI</h1>
          </div>
          {status !== AppStatus.IDLE && (
            <button onClick={handleReset} className="text-sm text-slate-500 hover:text-indigo-600 font-medium">
              New Photo
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-8 md:py-12 flex flex-col items-center justify-center">
        
        {/* Status: IDLE */}
        {status === AppStatus.IDLE && (
          <div className="w-full max-w-2xl text-center space-y-8 animate-fade-in">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Transform your selfie into a <span className="text-indigo-600">Pro Headshot</span>
              </h2>
              <p className="text-lg text-slate-600 max-w-xl mx-auto leading-relaxed">
                Using advanced AI to remove backgrounds, correct lighting, and dress you in professional business attire instantly.
              </p>
            </div>
            
            <div className="bg-white p-2 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100">
              <ImageUploader onImageSelected={handleImageSelected} isProcessing={false} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 text-left max-w-3xl mx-auto">
              {[
                { title: 'Smart Auto-Editing', desc: 'Fixes pose, lighting, and removes background automatically.' },
                { title: 'Business Attire', desc: 'Intelligently dresses you in a suit or professional blazer.' },
                { title: 'High Resolution', desc: 'Upscales your photo for crisp, CV-ready quality.' }
              ].map((feature, idx) => (
                <div key={idx} className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center mb-3">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-1">{feature.title}</h3>
                  <p className="text-sm text-slate-500">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Status: LOADING / PROCESSING */}
        {(status === AppStatus.ANALYZING || status === AppStatus.PROCESSING) && (
          <div className="flex flex-col items-center justify-center space-y-8 animate-fade-in py-12">
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-100 rounded-full animate-ping opacity-25"></div>
              <div className="relative bg-white p-6 rounded-full shadow-lg border border-indigo-50">
                <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-bold text-slate-900">{status === AppStatus.ANALYZING ? 'Analyzing Photo' : 'Creating Portrait'}</h3>
              <p className="text-slate-500">{loadingMsg}</p>
            </div>
            {/* Original Image Preview during loading */}
            {imageState.original && (
               <div className="w-32 h-32 rounded-xl overflow-hidden border-2 border-white shadow-md opacity-50 grayscale">
                  <img src={imageState.original} className="w-full h-full object-cover" alt="Processing" />
               </div>
            )}
          </div>
        )}

        {/* Status: SELECTING (Female) */}
        {status === AppStatus.SELECTING && (
          <OutfitSelector 
            options={FEMALE_OUTFITS} 
            onSelect={handleOutfitSelect} 
            isProcessing={false} 
          />
        )}

        {/* Status: COMPLETE */}
        {status === AppStatus.COMPLETE && imageState.final && imageState.original && (
          <ResultView 
            originalImage={imageState.original} 
            finalImage={imageState.final} 
            onReset={handleReset} 
          />
        )}

        {/* Status: ERROR */}
        {status === AppStatus.ERROR && (
          <div className="w-full max-w-md mx-auto text-center animate-fade-in p-8 bg-white rounded-2xl shadow-lg border border-slate-100">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Something went wrong</h3>
            <p className="text-slate-600 mb-6">{errorMsg}</p>
            <button 
              onClick={handleReset}
              className="px-6 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-medium transition-colors"
            >
              Try Again
            </button>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-sm text-slate-400">
            Powered by Google Gemini. Privacy focused: Images are processed and then discarded.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;